let regForm = document.querySelector(".register-form");
let allInput = regForm.querySelectorAll("INPUT");
let allBtn = regForm.querySelectorAll("BUTTON");
let closeBtn = document.querySelector(".btn-close");
let regList = document.querySelector(".reg-list");
let addBtn = document.querySelector(".add-btn");
let searchEl = document.querySelector(".search");
let dellAllBtn = document.querySelector(".delete-all-btn");
let allRegData = [];
let url = "";

if (localStorage.getItem("allRegData") !== null) {
    allRegData = JSON.parse(localStorage.getItem("allRegData"));
}

regForm.onsubmit = (e) => {
    e.preventDefault();
    let checkEmail = allRegData.find((data) => data.email === allInput[1].value);
    if (!checkEmail) {
        allRegData.push({
            name: allInput[0].value,
            email: allInput[1].value,
            mobile: allInput[2].value,
            dob: allInput[3].value,
            password: allInput[4].value, // Consider hashing before storing
            profile: url.trim() === "" ? "profile.jpg" : url
        });
        localStorage.setItem("allRegData", JSON.stringify(allRegData));
        swal("Data Inserted", "Successfully!", "success");
        closeBtn.click();
        regForm.reset();
        getRegData();
    } else {
        swal("Email already exists", "Failed", "warning");
    }
};

const getRegData = () => {
    regList.innerHTML = "";
    allRegData.forEach((data, index) => {
        let dataStr = JSON.stringify(data).replace(/"/g, "'");
        regList.innerHTML += `
        <tr>
            <td>${index + 1}</td>
            <td><img src="${data.profile}" width="30" alt="Profile"></td>
            <td>${data.name}</td>
            <td>${data.email}</td>
            <td>${data.mobile}</td>
            <td>${data.dob}</td>
            <td>
                <button data="${dataStr}" index="${index}" class="edit-btn p-1 px-2 btn-primary">
                    <i class="fa fa-edit"></i>
                </button>
                <button index="${index}" class="del-btn p-1 px-2 btn-danger">
                    <i class="fa fa-trash"></i>
                </button>
            </td>
        </tr>`;
    });
    action();
};

const action = () => {
    document.querySelectorAll(".del-btn").forEach((btn) => {
        btn.onclick = async () => {
            let isConfirm = await confirmDelete();
            if (isConfirm) {
                let index = btn.getAttribute("index");
                allRegData.splice(index, 1);
                localStorage.setItem("allRegData", JSON.stringify(allRegData));
                getRegData();
            }
        };
    });

    document.querySelectorAll(".edit-btn").forEach((btn) => {
        btn.onclick = () => {
            let index = btn.getAttribute("index");
            let data = JSON.parse(btn.getAttribute("data").replace(/'/g, '"'));
            addBtn.click();
            allInput[0].value = data.name;
            allInput[1].value = data.email;
            allInput[2].value = data.mobile;
            allInput[3].value = data.dob;
            allInput[4].value = data.password;
            url = data.profile;
            
            allBtn[0].disabled = false;
            allBtn[1].disabled = true;

            allBtn[0].onclick = () => {
                allRegData[index] = {
                    name: allInput[0].value,
                    email: allInput[1].value,
                    mobile: allInput[2].value,
                    dob: allInput[3].value,
                    password: allInput[4].value, // Consider hashing before storing
                    profile: url.trim() === "" ? "profile.jpg" : url
                };
                localStorage.setItem("allRegData", JSON.stringify(allRegData));
                swal("Data Updated", "Successfully!", "success");
                closeBtn.click();
                regForm.reset();
                getRegData();
                allBtn[1].disabled = false;
                allBtn[0].disabled = true;
            };
        };
    });
};

document.getElementById("file-input")?.addEventListener("change", (event) => {
    let file = event.target.files[0];
    if (file) {
        let reader = new FileReader();
        reader.onload = (e) => {
            url = e.target.result;
        };
        reader.readAsDataURL(file);
    }
});

dellAllBtn.onclick = async () => {
    let isConfirm = await confirmDelete();
    if (isConfirm) {
        allRegData = [];
        localStorage.removeItem("allRegData");
        getRegData();
    }
};

const confirmDelete = () => {
    return new Promise((resolve) => {
        swal({
            title: "Are you sure?",
            text: "Once deleted, you will not be able to recover this data!",
            icon: "warning",
            buttons: true,
            dangerMode: true,
        }).then((willDelete) => {
            if (willDelete) {
                resolve(true);
                swal("Deleted successfully!", { icon: "success" });
            } else {
                resolve(false);
                swal("Your data is safe!");
            }
        });
    });
};

searchEl.oninput = () => {
    let value = searchEl.value.toLowerCase();
    regList.querySelectorAll("tr").forEach((row) => {
        let allTd = row.querySelectorAll("td");
        let name = allTd[2]?.innerText.toLowerCase();
        let email = allTd[3]?.innerText.toLowerCase();
        let mobile = allTd[4]?.innerText.toLowerCase();
        row.style.display =
            name.includes(value) || email.includes(value) || mobile.includes(value)
                ? ""
                : "none";
    });
};

getRegData();
